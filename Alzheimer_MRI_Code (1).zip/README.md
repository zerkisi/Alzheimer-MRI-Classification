# Alzheimer's Disease Stage Classification from Brain MRI — Code

Zeynep Erkişi · 220302027 · Istanbul Arel University · Deep Learning Final Project

## Files
| File | Content |
| --- | --- |
| `Alzheimer_MRI_Classification.ipynb` | Main experiments: data loading and exploration, ANN baseline, CNN from scratch, EfficientNetB0 transfer learning, evaluation (metrics, confusion matrices, McNemar test, Grad-CAM) |
| `Part2_Leakage_and_Ablation.ipynb` | Data-leakage analysis (1-nearest-neighbour test) and augmentation ablation |

## How to run
1. Open the notebook in Google Colab.
2. Runtime → Change runtime type → T4 GPU.
3. Runtime → Run all (≈15–20 min for Part 1, ≈12–15 min for Part 2).

The dataset (`Falah/Alzheimer_MRI`, Hugging Face, Apache-2.0) is downloaded automatically.
Each notebook saves its figures and results and downloads them as a zip file at the end.

## Requirements
Python 3, TensorFlow/Keras, scikit-learn, scipy, pandas, matplotlib, seaborn, Hugging Face `datasets` (all preinstalled in Colab).

## Results folder
`results/part1_outputs` and `results/part2_outputs` hold the figures (PNG), result tables (CSV) and `results.json` files produced by the Colab runs used in the report.
